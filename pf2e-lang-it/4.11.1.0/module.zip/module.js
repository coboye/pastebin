// src/compat/autoanimations.ts
function compatAutoanimations() {
  if (!game.modules.has("autoanimations")) {
    return;
  }
  Hooks.on(
    "AutomatedAnimations-WorkflowStart",
    (data, animationData) => {
      if (animationData)
        return;
      let changed = false;
      if (data.item?.flags?.babele?.originalName) {
        data.item = createItemNameProxy(
          data.item,
          data.item.flags.babele.originalName
        );
        changed = true;
      }
      if (data.ammoItem?.flags?.babele?.originalName) {
        data.ammoItem = createItemNameProxy(
          data.ammoItem,
          data.ammoItem.flags.babele.originalName
        );
        changed = true;
      }
      if (data.originalItem?.flags?.babele?.originalName) {
        data.originalItem = createItemNameProxy(
          data.originalItem,
          data.originalItem.flags.babele.originalName
        );
        changed = true;
      }
      if (changed) {
        data.recheckAnimation = true;
      }
    }
  );
}
function createItemNameProxy(item, realName) {
  return new Proxy(item, {
    get(target, p, receiver) {
      if (p === "name") {
        return realName;
      }
      return Reflect.get(target, p, receiver);
    }
  });
}

// src/utils.ts
function localizeWith(source, stringId) {
  const v = foundry.utils.getProperty(source, stringId);
  return typeof v === "string" ? v : stringId;
}
function formatWith(source, stringId, data = {}) {
  let str = localizeWith(source, stringId);
  const fmt = /{[^}]+}/g;
  str = str.replace(fmt, (k) => {
    return data[k.slice(1, -1)];
  });
  return str;
}
function convertFeetString(v) {
  return convertFeet(parseInt(v.replace(/,/g, ""))).toLocaleString("it-IT");
}
function convertMilesString(v) {
  return convertMiles(parseInt(v.replace(/,/g, ""))).toLocaleString("it-IT");
}
function convertFeet(v) {
  if (v % 5 == 0) {
    return v / 5 * 1.5;
  }
  return round(v * 0.3);
}
function convertMiles(v) {
  return round(v * 1.6);
}
function round(num) {
  return Math.round((num + Number.EPSILON) * 100) / 100;
}
function removeMismatchingTypes(fallback, other = {}) {
  for (let k of Object.keys(other)) {
    const replacement = other[k];
    const replacementType = getType(replacement);
    if (!fallback.hasOwnProperty(k)) {
      delete other[k];
      continue;
    }
    const original = fallback[k];
    const originalType = getType(original);
    if (replacementType === "Object" && originalType === "Object") {
      removeMismatchingTypes(original, replacement);
      continue;
    }
    if (originalType !== "undefined" && replacementType !== originalType) {
      delete other[k];
    }
  }
  return fallback;
}

// src/converter-distance.ts
function distancePf2(distance, translation) {
  if (translation) {
    return translation;
  }
  if (!distance || !shouldConvertUnits()) {
    return distance;
  }
  const num = typeof distance === "string" ? parseInt(distance) : distance;
  return convertFeet(num);
}

// src/spellcasting-entry.ts
var spellcastingEntries = {};
function generateSpellcastingEntryTitles(en) {
  spellcastingEntries = {};
  for (const prepKey of Object.values(CONFIG.PF2E.preparationType)) {
    for (const tradKey of Object.values(CONFIG.PF2E.magicTraditions)) {
      const originalPrep = localizeWith(en, prepKey);
      const originalTrad = localizeWith(en, tradKey);
      const originalSpellcasting = formatWith(en, "PF2E.SpellCastingFormat", {
        preparationType: originalPrep,
        traditionSpells: originalTrad
      });
      const translatedPrep = game.i18n.localize(prepKey);
      const translatedTrad = game.i18n.localize(tradKey);
      const translatedSpellcasting = game.i18n.format(
        "PF2E.SpellCastingFormat",
        {
          preparationType: translatedPrep,
          traditionSpells: translatedTrad
        }
      );
      spellcastingEntries[originalSpellcasting] = translatedSpellcasting;
    }
  }
}

// src/converter-from-pack.ts
var dynamicMapping = new CompendiumMapping("Item");
function getTranslationForItem(data, translations) {
  if (Array.isArray(translations)) {
    return translations.find((t) => t.id === data._id || t.id === data.name);
  } else {
    return translations[data._id] || translations[data.name];
  }
}
function findTranslationSource(sourceId) {
  const m = sourceId.match(
    /^Compendium\.pf2e\.([^\.]+).([^\.]+)(?:\.Item\.([^\.]+))?$/
  );
  if (m) {
    const [_, packName, id, itemId] = m;
    const pack = game.babele.packs.get(`pf2e.${packName}`);
    if (!pack) {
      return null;
    }
    const foundryPack = game.packs.get(`pf2e.${packName}`);
    const referenced = foundryPack.index.get(id);
    const referencedName = referenced.originalName ?? referenced.name;
    const referencedTranslation = pack.translationsFor({
      _id: id,
      name: referencedName
    });
    if (!itemId) {
      return [referencedTranslation, pack.mapping];
    }
    if (referencedTranslation?.items) {
      const items = foundryPack.get(id)?.items;
      if (!items) {
        return null;
      }
      const name = items?.find((item) => item._id == itemId);
      return [
        getTranslationForItem(
          { _id: itemId, name },
          referencedTranslation.items
        ),
        dynamicMapping
      ];
    }
  }
  return null;
}
var fromPackPf2 = (items, translations) => {
  return items.map((data) => {
    let translationData;
    let translationSource;
    if (translations) {
      const translation = getTranslationForItem(data, translations);
      if (translation) {
        const { _source, ...rest } = translation;
        translationData = dynamicMapping.map(data, rest);
        translationSource = _source ? `Compendium.pf2e.${_source}` : null;
      }
    }
    const sourceId = translationSource ?? data.flags?.core?.sourceId;
    if (sourceId) {
      const found = findTranslationSource(sourceId);
      if (found) {
        const [translationData1, mapping] = found;
        translationData = mergeObject(
          mapping.map(data, translationData1),
          translationData
        );
      }
    }
    if (!sourceId && (data.type === "melee" || data.type === "ranged")) {
      const equipmentTranslation = game.babele.packs.get("pf2e.equipment-srd").translationsFor({ _id: "", name: data.name });
      translationData = dynamicMapping.map(
        data,
        mergeObject(equipmentTranslation, translationData ?? {}, {
          inplace: false
        })
      );
    }
    if (data.type === "spellcastingEntry") {
      const spellcastingEntryName = spellcastingEntries[data.name];
      if (spellcastingEntryName) {
        translationData = { name: spellcastingEntryName };
      }
    }
    if (!translationData) {
      return data;
    }
    return mergeObject(
      data,
      mergeObject(
        translationData,
        {
          translated: true,
          flags: {
            babele: {
              translated: true,
              hasTranslation: true,
              originalName: data.name
            }
          }
        },
        { inplace: false }
      ),
      { inplace: false }
    );
  });
};

// src/converter-range.ts
function rangePf2(range, translation) {
  if (translation) {
    return translation;
  }
  if (!range || !shouldConvertUnits()) {
    return range;
  }
  range = range.toLowerCase();
  if (range === "touch") {
    return "contatto";
  }
  if (range === "planetary") {
    return "planetario";
  }
  const match = range.match(/^([\d.,]+)\s*(|feet|foot|miles?)$/);
  if (match) {
    const [rangeStr, type] = match;
    if (!type || type === "feet" || type === "foot") {
      return `${convertFeetString(rangeStr)} metri`;
    }
    if (type.startsWith(" mile")) {
      return `${convertMilesString(rangeStr)} miglia`;
    }
  }
  return range;
}

// src/converter-speeds.ts
var speedPf2 = (speed, translation) => {
  if (!speed) {
    return speed;
  }
  return {
    ...speed,
    details: translation || speed.details,
    value: shouldConvertUnits() ? convertFeet(speed.value) : speed.value,
    otherSpeeds: speed.otherSpeeds.map((s) => ({
      ...s,
      value: shouldConvertUnits() ? convertFeet(speed.value) : speed.value
    }))
  };
};
var otherSpeedsPf2 = (otherSpeeds, translation) => {
  if (!otherSpeeds || !translation) {
    return otherSpeeds;
  }
  return otherSpeeds.map((s) => {
    const translated = translation[s.type];
    if (translated) {
      return { ...s, label: translated };
    }
    return s;
  });
};

// src/converter-time.ts
var allowedTimes = ["1", "2", "3", "free", "reaction"];
function timePf2(time, translation) {
  if (translation) {
    return translation;
  }
  if (!time || typeof time !== "string") {
    return time;
  }
  time = time.toLowerCase();
  if (allowedTimes.includes(time)) {
    return time;
  }
  const match = time.match(/^([\d.,]+)\s*(minutes?|days?|hours?)$/);
  if (match) {
    const [timeStr, type] = match;
    if (type.startsWith("minute")) {
      return `${timeStr} minut${type.endsWith("s") ? "i" : "o"}`;
    }
    if (type.startsWith("hour")) {
      return `${timeStr} or${type.endsWith("s") ? "e" : "a"}`;
    }
    if (type.startsWith("day")) {
      return `${timeStr} giorn${type.endsWith("s") ? "i" : "o"}`;
    }
  }
  return time;
}

// src/libwrapper.js
var libWrapper = void 0;
var TGT_SPLIT_RE = new RegExp(
  `([^.[]+|\\[('([^'\\\\]|\\\\.)+?'|"([^"\\\\]|\\\\.)+?")\\])`,
  "g"
);
var TGT_CLEANUP_RE = new RegExp(`(^\\['|'\\]$|^\\["|"\\]$)`, "g");
Hooks.once("init", () => {
  if (globalThis.libWrapper && !(globalThis.libWrapper.is_fallback ?? true)) {
    libWrapper = globalThis.libWrapper;
    return;
  }
  libWrapper = class {
    static get is_fallback() {
      return true;
    }
    static get WRAPPER() {
      return "WRAPPER";
    }
    static get MIXED() {
      return "MIXED";
    }
    static get OVERRIDE() {
      return "OVERRIDE";
    }
    static register(package_id, target, fn, type = "MIXED", { chain = void 0, bind = [] } = {}) {
      const is_setter = target.endsWith("#set");
      target = !is_setter ? target : target.slice(0, -4);
      const split = target.match(TGT_SPLIT_RE).map((x) => x.replace(/\\(.)/g, "$1").replace(TGT_CLEANUP_RE, ""));
      const root_nm = split.splice(0, 1)[0];
      let obj, fn_name;
      if (split.length == 0) {
        obj = globalThis;
        fn_name = root_nm;
      } else {
        const _eval = eval;
        fn_name = split.pop();
        obj = split.reduce(
          (x, y) => x[y],
          globalThis[root_nm] ?? _eval(root_nm)
        );
      }
      let iObj = obj;
      let descriptor = null;
      while (iObj) {
        descriptor = Object.getOwnPropertyDescriptor(iObj, fn_name);
        if (descriptor)
          break;
        iObj = Object.getPrototypeOf(iObj);
      }
      if (!descriptor || descriptor?.configurable === false)
        throw new Error(
          `libWrapper Shim: '${target}' does not exist, could not be found, or has a non-configurable descriptor.`
        );
      let original = null;
      const wrapper = chain ?? (type.toUpperCase?.() != "OVERRIDE" && type != 3) ? function(...args) {
        return fn.call(this, original.bind(this), ...bind, ...args);
      } : function(...args) {
        return fn.call(this, ...bind, ...args);
      };
      if (!is_setter) {
        if (descriptor.value) {
          original = descriptor.value;
          descriptor.value = wrapper;
        } else {
          original = descriptor.get;
          descriptor.get = wrapper;
        }
      } else {
        if (!descriptor.set)
          throw new Error(
            `libWrapper Shim: '${target}' does not have a setter`
          );
        original = descriptor.set;
        descriptor.set = wrapper;
      }
      descriptor.configurable = true;
      Object.defineProperty(obj, fn_name, descriptor);
    }
  };
  {
    const [PACKAGE_ID, PACKAGE_TITLE] = (() => {
      const match = (import.meta?.url ?? Error().stack)?.match(
        /\/(worlds|systems|modules)\/(.+)(?=\/)/i
      );
      if (match?.length !== 3)
        return [null, null];
      const dirs = match[2].split("/");
      if (match[1] === "worlds")
        return dirs.find((n) => n && game.world.id === n) ? [game.world.id, game.world.title] : [null, null];
      if (match[1] === "systems")
        return dirs.find((n) => n && game.system.id === n) ? [game.system.id, game.system.title ?? game.system.data.title] : [null, null];
      const id = dirs.find((n) => n && game.modules.has(n));
      const mdl = game.modules.get(id);
      return [id, mdl?.title ?? mdl?.data?.title];
    })();
    if (!PACKAGE_ID || !PACKAGE_TITLE) {
      console.error(
        "libWrapper Shim: Could not auto-detect package ID and/or title. The libWrapper fallback warning dialog will be disabled."
      );
      return;
    }
    Hooks.once("ready", () => {
      const FALLBACK_MESSAGE_TITLE = PACKAGE_TITLE;
      const FALLBACK_MESSAGE = `
				<p><b>'${PACKAGE_TITLE}' depends on the 'libWrapper' module, which is not present.</b></p>
				<p>A fallback implementation will be used, which increases the chance of compatibility issues with other modules.</p>
				<small><p>'libWrapper' is a library which provides package developers with a simple way to modify core Foundry VTT code, while reducing the likelihood of conflict with other packages.</p>
				<p>You can install it from the "Add-on Modules" tab in the <a href="javascript:game.shutDown()">Foundry VTT Setup</a>, from the <a href="https://foundryvtt.com/packages/lib-wrapper">Foundry VTT package repository</a>, or from <a href="https://github.com/ruipin/fvtt-lib-wrapper/">libWrapper's Github page</a>.</p></small>
			`;
      const DONT_REMIND_AGAIN_KEY = "libwrapper-dont-remind-again";
      console.warn(
        `${PACKAGE_TITLE}: libWrapper not present, using fallback implementation.`
      );
      game.settings.register(PACKAGE_ID, DONT_REMIND_AGAIN_KEY, {
        name: "",
        default: false,
        type: Boolean,
        scope: "world",
        config: false
      });
      if (game.user.isGM && !game.settings.get(PACKAGE_ID, DONT_REMIND_AGAIN_KEY)) {
        new Dialog({
          title: FALLBACK_MESSAGE_TITLE,
          content: FALLBACK_MESSAGE,
          buttons: {
            ok: { icon: '<i class="fas fa-check"></i>', label: "Understood" },
            dont_remind: {
              icon: '<i class="fas fa-times"></i>',
              label: "Don't remind me again",
              callback: () => game.settings.set(PACKAGE_ID, DONT_REMIND_AGAIN_KEY, true)
            }
          }
        }).render(true);
      }
    });
  }
});

// src/index.ts
var LANG = "it";
var ID = "pf2e-lang-it";
var convertEnabled = false;
function shouldConvertUnits() {
  return convertEnabled && game.i18n.lang === LANG;
}
Hooks.once("init", () => {
  if (typeof Babele === "undefined") {
    return;
  }
  Babele.get().register({
    module: ID,
    lang: LANG,
    dir: "lang/compendiums"
  });
  Babele.get().registerConverters({
    [`${ID}-fromPack`]: fromPackPf2,
    [`${ID}-range`]: rangePf2,
    [`${ID}-time`]: timePf2,
    [`${ID}-list`]: listPf2,
    [`${ID}-distance`]: distancePf2,
    [`${ID}-speed`]: speedPf2,
    [`${ID}-otherSpeeds`]: otherSpeedsPf2,
    [`${ID}-heightening`]: heighteningPf2
  });
});
Hooks.once("ready", () => {
  libWrapper.register(
    ID,
    "game.i18n.format",
    (wrapped, stringId, data) => {
      if (shouldConvertUnits()) {
        if (stringId === "PF2E.SpellArea") {
          data.areaSize = convertFeet(data.areaSize);
        }
        if (stringId === "PF2E.Item.Spell.PlaceMeasuredTemplate") {
          data.size = convertFeet(data.size);
        }
      }
      return wrapped(stringId, data);
    },
    "WRAPPER"
  );
  compatAutoanimations();
});
Hooks.once("i18nInit", () => {
  if (game.i18n.lang === LANG) {
    const fallback = game.i18n._fallback;
    removeMismatchingTypes(fallback, game.i18n.translations);
    generateSpellcastingEntryTitles(fallback);
  }
});
Hooks.once("babele.ready", () => {
  game.pf2e.ConditionManager.initialize();
});
function heighteningPf2(value, translation) {
  return value;
}
function listPf2(value, translation) {
  if (!value || !Array.isArray(value) || !translation)
    return value;
  return value.map((v, i) => {
    if (!v || !v.value) {
      return v;
    }
    const t = translation[`${i}`];
    if (!t) {
      return v;
    }
    return { value: t };
  });
}
export {
  shouldConvertUnits
};
